																																																												<?php


if(substr($validity,-1) == "d"){
  $validity = "MASA AKTIF : ".substr($validity,0,-1)." HARI";
}else if(substr($validity,-1) == "h"){
  $validity = "MASA AKTIF : ".substr($validity,0,-1)." JAM";
}
if(substr($timelimit,-1) == "d" & strlen($timelimit) >3){
  $timelimit = "Durasi:".((substr($timelimit,0,-1)*7) +  substr($timelimit, 2,1))."HARI";
}else if(substr($timelimit,-1) == "d"){
  $timelimit = "Durasi:".substr($timelimit,0,-1)."HARI";
}else if(substr($timelimit,-1) == "h"){
  $timelimit = "Durasi:".substr($timelimit,0,-1)."JAM";
}else if(substr($timelimit,-1) == "w"){
  $timelimit = "Durasi:".(substr($timelimit,0,-1)*7)."HARI";
}	            	            

if($getsprice == "2500"){ $eko = "border:none; width: 212px; height:125px; background: url('../img/vc3000.png') no-repeat; background-size:contain;";} 
elseif($getsprice == "1000"){ $eko = "border:none; width: 212px; height:125px; background: url('../img/vc1000.png') no-repeat; background-size:contain;";}
elseif($getsprice == "2000"){ $eko = "border:none; width: 212px; height:125px; background: url('../img/vc2000.png') no-repeat; background-size:contain;";}
elseif($getsprice == "3000"){ $eko = "border:none; width: 212px; height:125px; background: url('../img/vc3000.png') no-repeat; background-size:contain;";}
elseif($getsprice == "4500"){ $eko = "border:none; width: 212px; height:125px; background: url('../img/vc5000.png') no-repeat; background-size:contain;";}
elseif($getsprice == "10000"){ $eko = "border:none; width: 212px; height:125px; background: url('../img/vc10000.png') no-repeat; background-size:contain;";}
elseif($getsprice == "14500"){ $eko = "border:none; width: 212px; height:125px; background: url('../img/vc15000.png') no-repeat; background-size:contain;";}
elseif($getsprice == "20000"){ $eko = "border:none; width: 212px; height:125px; background: url('../img/vc20000.png') no-repeat; background-size:contain;";}
elseif($getsprice == "39500"){ $eko = "border:none; width: 212px; height:125px; background: url('../img/vc40000.png') no-repeat; background-size:contain;";}
else{ $eko = "border:none; width: 212px; height:125px; background: url('../img/vcfree.png') no-repeat; background-size:contain;";}
?>
<style>
.qrcode{
height:58px;
width:58px;}
</style>

<tr>
<td style="color:#666;border-collapse: collapse;" valign="top">
<table class="voucher" style="border:none; width: 212px; height:125px; background: <?php echo $eko ?> no-repeat; background-size:contain;">
<tbody>
<tr>
<td style="width:30px"valign="top" >
<div style="margin-bottom: 10px; margin-left:2px;margin-top:2px; ">
<img style="height:25px; border-radius:5px;width:80px;" src="<?php echo $logo;?>">
<div style="float:right;width:5%;text-align:right;font-size:5px;color:#666; margin-right:5px;">
<?php echo " [$num]";?>
</div>
<div style="clear:both;color:black;margin-top:18px;margin-bottom:10px;">
<?php if($v_opsi=='up'){ ?>
<?php }else{ ?>
<div style=" margin-left:15px;font-weight:bold;font-size:15px;"><?php echo $username;?> <?php echo $password;?></div>
<div style="margin-top:5px; margin-left:14px; text-align:center;color:#111;font-size:7px;padding:0px;">

	untuk login / logout :

</div>
<div style="margin-left:14px; text-align:center;color:#111;font-size:7px;font-weight:bold;padding:1px;">
<i>www.kyl.net</i>
</div>
<?php } ?>
<td style="width:100px;text-align:left;">
<td style="width:150px; height:150px">
<div style="margin-top:31px;margin-left:45px; ;font-weight:bold;font-size:6px;color:#111;"><?php echo $validity;?></div>
<div style=" margin-top:7px; margin-left:52px;"><?= $qrcode ?></div>
<div style="margin-top:1px; margin-left:40px; text-align:left;color:white;font-size:9px;font-weight:bold;padding:2.5px;">
CS:DUDUNG
</div>
<!-- NUM -->
<div style="margin-bottom: 10px; margin-left:125px;margin-top:10px;color:#fff;font-size:10px;padding:0px;"><?php echo " [$num] ";?></div> 
<!-- NUM -->
</td>
</tr>
</tbody>
</table>
</td>
</tr>	        	        	        	        	        	        	        	        	        	        