<?php 
if(substr($_SERVER["REQUEST_URI"], -10) == "config.php"){header("Location:./");}; 
$data['mikhmon'] = array ('1'=>'mikhmon<|<mikhmon','mikhmon>|>g5KrpJJjamRy');

$data['Kyl.10'] = array ('1'=>'Kyl.10!192.33.33.1','Kyl.10@|@Syabilla','Kyl.10#|#g5KrpJJjamRy','Kyl.10%Kyl','Kyl.10^Kyl.net','Kyl.10&Rp','Kyl.10*10','Kyl.10(1','Kyl.10)','Kyl.10=10','Kyl.10@!@disable');
$data['Kyl'] = array ('1'=>'Kyl!id-23.hostddns.us:10221','Kyl@|@Syabilla2222','Kyl#|#g5KrpJJjamRyeHFy','Kyl%Kyl','Kyl^Kyl.net','Kyl&Rp','Kyl*10','Kyl(1','Kyl)','Kyl=10','Kyl@!@disable');